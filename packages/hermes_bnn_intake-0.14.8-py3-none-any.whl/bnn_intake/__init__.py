"""Optional semantic preparation; the host remains the authority."""

__version__ = "0.14.8"
SCHEMA_VERSION = 6
