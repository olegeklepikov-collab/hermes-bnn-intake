"""Optional semantic preparation; the host remains the authority."""

__version__ = "0.14.10"
SCHEMA_VERSION = 6
